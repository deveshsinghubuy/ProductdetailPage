"use client"

import React from 'react'
import {Swiper, SwiperSlide} from "swiper/react";
import "swiper/css"
import { useState } from "react";
import Image from 'next/image'
import { FaWhatsapp, FaFacebookF,FaInfoCircle, FaTwitter, FaHeart,FaCheck, FaStar, FaStarHalfAlt, FaRegStar,FaPencilAlt  } from "react-icons/fa";

import Productcontent from './component/Productcontent';

const Product = () => {

    const iconStyle = "text-2xl m-2 cursor-pointer hover:text-blue-500 transition-colors";
    const [liked, setLiked] = useState(false);

    const slides = [
        { src: "/images/dss.svg", text: "PCI DSS Compliance" },
        { src: "/images/dss.svg", text: "ISO Certified" },
        { src: "/images/dss.svg", text: "Data Encryption" },
        { src: "/images/dss.svg", text: "Secure Payment" },
        { src: "/images/dss.svg", text: "Privacy Protection" },
        { src: "/images/dss.svg", text: "Data Encryption" },
        { src: "/images/dss.svg", text: "Privacy Protection" },
        { src: "/images/dss.svg", text: "Secure Payment" },
        { src: "/images/dss.svg", text: "ISO Certified" },
        { src: "/images/dss.svg", text: "Privacy Protection" },
    ];
    
    const toggleLike = () => {
        setLiked(!liked);
    };

  return (
    <div className='flex justify-center'>
        <div className='max-w-[2050px] w-full flex justify-center '>
            <div className='w-[92%] flex gap-15 my-10 '>
                
                {/* left */}
                <div className='w-[72%] '>
                    {/* hero section */}
                    <div className='flex gap-10 relative'>
                        {/* product */}
                        <div className='relative'>
                            <div className='flex sticky top-10 flex-col gap-10 p-5 '>
                                <div className='flex flex-col gap-5 border-1 border-neutral-200 shadow p-5 rounded-xl' >
                                    <div className='flex justify-end items-center'>
                                        <button onClick={toggleLike} className="cursor-pointer text-2xl focus:outline-none rounded-full p-2 bg-white shadow-md transition-colors">
                                            <FaHeart size={16} className={`transition-colors  ${liked ? "text-red-500" : "text-gray-200"}`} />
                                        </button>
                                    </div>
                                    <div className='flex justify-center px-20'>
                                        <div>
                                            <Image src="/images/productImage.jpg" alt='image' width={400} height={400}></Image>
                                        </div>
                                    </div>
                                    <div className='flex gap-10 justify-center items-center my-5'>
                                        <a href="https://wa.me/your-number" target="_blank" rel="noopener noreferrer">
                                            <FaWhatsapp className={iconStyle} style={{ color: "#25D366" }} />
                                        </a>
                                        <a href="https://facebook.com/your-page" target="_blank" rel="noopener noreferrer">
                                            <FaFacebookF className={iconStyle} style={{ color: "#3b5998" }} />
                                        </a>
                                        <a href="https://twitter.com/your-profile" target="_blank" rel="noopener noreferrer">
                                            <FaTwitter className={iconStyle} style={{ color: "#1DA1F2" }} />
                                        </a>
                                    </div>
                                </div>
                                <div className='flex justify-between  gap-5 '>
                                    <div className='p-3 rounded-md  border-1 border-neutral-300'><Image src="/images/productImage.jpg" alt='image' width={70} height={60}></Image></div>
                                    <div className='p-3 rounded-md  border-1 border-neutral-300'><Image src="/images/productImage.jpg" alt='image' width={70} height={60}></Image></div>
                                    <div className='p-3 rounded-md  border-1 border-neutral-300'><Image src="/images/productImage.jpg" alt='image' width={70} height={60}></Image></div>
                                    <div className='p-3 rounded-md  border-1 border-neutral-300'><Image src="/images/productImage.jpg" alt='image' width={70} height={60}></Image></div>
                                    <div className='p-3 rounded-md  border-1 border-neutral-300'><Image src="/images/productImage.jpg" alt='image' width={70} height={60}></Image></div>
                                </div>
                                <div>
                                    <p className='text-[15px] font-semibold italic w-[90%]'>Bust odor and smell irresistible for 48 hours with our Body Spray Deodorant</p>
                                </div>
                            </div>
                        </div> 
                        
                        {/* cotent */}
                        <div className='w-[47%] '>
                            <div className='flex flex-col gap-4'>
                                <a href="https://your-link.com" target="_blank" rel="noopener noreferrer">AXIE</a>
                                <h1 className='text-[22px] font-bold '>AXE Apollo Body Spray Deodorant for Long-Lasting Odor Protection, Sage & Cedarwood Deodorant for Men Formulated Without Aluminum 4oz 4 Count</h1>
                                <p><strong className='text-[#198975] text-[17px]'>89%</strong> <span className="italic text-[13px]"> of respondents would recommend this to a friend</span></p>
                                <div className='text-[14px] font-semibold'>Item #:<span> 79956169</span></div>
                                <div className='flex gap-2 items-center'>
                                    <h3 className='text-[24px] font-extrabold'>INR 2261</h3>
                                    <del className='text-[14px] text-red-500'>INR 2999</del>
                                    <FaInfoCircle size={15} color="#1E90FF" className="cursor-pointer" />
                                    <p>You Save : 11%</p>
                                </div>
                                <div className='flex items-center gap-3'>
                                    <div className='flex gap-1 items-center'>
                                        <FaStar size={20} className="text-yellow-500" />
                                        <FaStar size={20} className="text-yellow-500" />
                                        <FaStar size={20} className="text-yellow-500" />
                                        <FaStar size={20} className="text-yellow-500" />
                                        <FaStarHalfAlt size={20} className="text-yellow-500" />
                                    </div>
                                    <p className='text-[14px]'>4.7 rating</p>      
                                    <button className='flex items-center gap-2'>
                                        <FaPencilAlt size={16} color="#333" />
                                        <p className='text-[14px]'>Write a review</p>
                                    </button>
                                </div>
                                <p className='italic text-[13px] text-[#666]'>10K+ bought</p>
                                <div className='flex justify-between text-[#151515] font-semibold'>
                                    <div className='text-[14px] flex items-center'><label>Availability :</label><span className='text-[#198754] font-medium px-1'>In stock</span><FaCheck className="ms-1 text-green-600 text-md"/></div>
                                    <div className='flex gap-2'><Image src="/images/us.svg" alt='image' width={20} height={20}></Image><span className='text-[14px] font-semibold'>Imported from USA store</span></div>
                                </div>

                                <div className='border-1 border-neutral-200 px-7 py-3 pb-4 mt-4 rounded-xl font-medium'>
                                    <button className='flex items-center mb-5 gap-1'><p className='flex items-center gap-1 font-extrabold'>Scent<span>:</span></p><strong>Apollo (Sage and Cedarwood)</strong></button>
                                    <button className='border-1 px-3 py-2 text-[#666]  border-[#ffb100] rounded-sm'>Apollo (Sage and Cedarwood)</button>
                                </div>
                                <div className='border-1 border-neutral-200 px-7 py-3 pb-4 rounded-xl'>
                                    <button className='flex items-center mb-5 gap-1'><p className='flex items-center gap-1  font-extrabold'>Size<span>:</span></p><strong>4 Ounce (Pack of 4)</strong></button>
                                    <button className='border-1 px-3 py-2  text-[#666] border-[#ffb100] rounded-sm'>4 Ounce (Pack of 4)</button>
                                </div>
                                <div className='flex gap-5'>
                                    <div className='pt-1'>
                                    <Image src="/images/truck.svg" alt='image' width={48} height={46}></Image>
                                    </div>
                                    <div>
                                        <p className='text-[14px] mb-4'>Add additional items worth <span className='text-[#ffb100]'>INR 9439.2</span> to get <span className='text-[#ffb100]'>Fast Shipping</span> at standard shipping price.</p>
                                        <div className="w-full bg-gray-200 rounded-full h-1.5 overflow-hidden">
                                            <div className="bg-[#ffb100] h-1.5 transition-all duration-300" style={{ width: `20%` }}></div>
                                        </div>
                                    </div>
                                </div>
                                <div className='px-2 border border-neutral-200 rounded-md'>
                                    <div className='flex items-center border-b border-neutral-200 py-6'>
                                    <Swiper
                                        slidesPerView={5}
                                        loop={true}
                                        spaceBetween={20}
                                        grabCursor={true}
                                        className="mySwiper"
                                        >
                                        {slides.map((item, i) => (
                                            <SwiperSlide key={i}>
                                            <div className="flex flex-col items-center justify-center text-center">
                                                <Image src={item.src} alt={item.text} width={30} height={30} />
                                                <h5 className="text-[12px] text-[#666] mt-1">{item.text}</h5>
                                            </div>
                                            </SwiperSlide>
                                        ))}
                                        </Swiper>
                                    </div>
                                    <div>
                                        <div className='flex justify-between p-5 '>
                                            <Image src="/images/payment_methods-175367948814.png" alt='image' width={61} height={40}></Image>
                                            <Image src="/images/payment_methods-175369014491.png" alt='image' width={61} height={40}></Image>
                                            <Image src="/images/payment_methods-175368113152.png" alt='image' width={61} height={40}></Image>
                                            <Image src="/images/payment_methods-175367948814.png" alt='image' width={61} height={40}></Image>
                                            <Image src="/images/payment_methods-175367948814.png" alt='image' width={61} height={40}></Image>
                                            <Image src="/images/payment_methods-175368113152.png" alt='image' width={61} height={40}></Image>
                                            <Image src="/images/payment_methods-175369014491.png" alt='image' width={61} height={40}></Image>
                                        </div>
                                    </div>
                                </div>
                                <div className='flex flex-col gap-2'>
                                    <p className='text-[14px]'>Ships from Ubuy, Sold by : <span className='cursor-pointer underline decoration-black hover:text-[#ffb100] hover:decoration-[#ffb100] underline-offset-4  font-semibold'> A 2 Z STORE</span></p>
                                    <p className='text-[13px]'>Note: Step Down Voltage Transformer required for using electronics products of US store (110-120). Recommended power converters <a href="#" className='underline hover:text-[#ffb100] hover:decoration-[#ffb100]  font-semibold'>Buy Now</a></p>
                                </div>
                            </div>
                        </div>

                    </div>
                    {/* description section */}
                    <Productcontent></Productcontent>
                </div>
                 {/* right */}
                {/* sticky */}
                <div className="relative w-[28%]">
                    <div className="sticky top-10 h-[610px] shadow-xl border border-neutral-100 p-8 rounded-md overflow-y-auto custom-scrollbar">
                        <div>
                        <div className='flex flex-col gap-3'>
                            <span className='flex gap-2'>
                            <h2 className='text-[24px] font-extrabold'>INR 2261</h2>
                            <del className='text-red-600 pt-[3px]'>INR 2536</del>
                            </span>
                            <p className='text-[13px] text-[#198975] font-semibold'>Order now and get it around Friday, October 24</p>
                            <div>QTY:</div>
                            <p className='italic text-[#dc3545] font-semibold'>Only 5 items left in stock.</p>
                            <button className='py-4 cursor-pointer text-white bg-black hover:text-black hover:bg-[#ffb100] rounded-md'>Add to cart</button>
                            <button className='py-4 cursor-pointer text-black bg-[#ffb100] rounded-md'>Buy Now</button>
                            <h5 className='text-[14px] text-[#666] font-medium'>Secured transaction</h5>    
                            <div>
                            <h3 className='text-[14px] font-semibold'>Our Top Logistics Partners</h3>
                            <div className='flex gap-3 mt-2'>
                                <Image src="/images/productimage.jpg" alt='image' width={40} height={20}></Image>
                                <Image src="/images/productimage.jpg" alt='image' width={40} height={20}></Image>
                            </div>
                            </div>
                            <p className='text-[13px] text-[#198975] font-semibold'>Fastest cross-border delivery</p>
                            <div>
                            <h3>Features & Benefits</h3>
                            <ul className='p-5 h-[200px] text-[14px] list-disc overflow-y-auto custom-scrollbar'>
                                <li>AXE Apollo Body Spray Deodorant for men keeps you smelling awesome all day, every day</li>
                                <li>Fights odor and leaves you smelling irresistible day and night</li>
                                <li>Sage and cedarwood fragrance keeps you totally fresh and 100% ready</li>
                                <li>Dedicated to providing the best tools for an irresistible fragrance</li>
                                <li>All packaging to be recyclable or include recycled materials by 2025</li>
                                <li>Part of the attraction game with body spray, shower gels, antiperspirants, and deodorants</li>
                            </ul>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  )
}

export default Product
