import React from 'react'
import Product from './pages/Product'

const page = () => {
  return (
    <div>
        <Product></Product>
        
    </div>
  )
}

export default page
