import ShippingForm from "./components/ShippingForm";

const CartPage = ()=>{

    return(
       <div>
            
            <ShippingForm></ShippingForm>
       </div>
    )
}
export default CartPage;