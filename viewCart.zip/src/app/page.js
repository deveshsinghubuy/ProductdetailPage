import React from 'react'
import Product from './pages/product/page'
import ShippingForm from './pages/cart/components/ShippingForm'
import ViewCartPage from './pages/viewcart/page'

const page = () => {
  return (
    <div>
        {/* <Product></Product> */}
            {/* <ShippingForm></ShippingForm> */}
         <ViewCartPage></ViewCartPage>   
        
    </div>
  )
}

export default page
